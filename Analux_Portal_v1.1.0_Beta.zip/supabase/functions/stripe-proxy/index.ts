import { createClient } from "https://esm.sh/@supabase/supabase-js@2"
import Stripe from "https://esm.sh/stripe@14.24.0?target=deno"

const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
}

Deno.serve(async (req) => {
    // 1. Handle CORS Preflight
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders })
    }

    try {
        // 2. Configuration & Initialization
        const supabaseUrl = Deno.env.get('SUPABASE_URL')
        const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

        // HARDCODED - FALLBACK (Keep for immediate testing reliability as requested)
        const stripeKey = Deno.env.get('STRIPE_SECRET_KEY') || 'sk_test_51StYw8Div2beAnVSMFfhUTA4lZiXMYDabnSsGWZ5nQZucxTk94djaCCgzTG3dreVZkoXz4uv5rwAVW4eEqTLWLm500TZNuLZJk';
        const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

        if (!supabaseUrl || !supabaseKey) {
            console.error("Critical: Supabase Config Missing");
            return new Response(JSON.stringify({ error: 'Server Config Error' }), { status: 500, headers: corsHeaders })
        }

        const supabase = createClient(supabaseUrl, supabaseKey)
        const stripe = new Stripe(stripeKey, {
            apiVersion: '2023-10-16',
            httpClient: Stripe.createFetchHttpClient(),
        })

        // 3. Request Routing (Webhook vs Client API)
        const signature = req.headers.get('Stripe-Signature');

        if (signature) {
            // ==========================================
            //  WEBHOOK HANDLING (Server-Server)
            // ==========================================
            console.log(`[Webhook] Received event with signature.`);
            const body = await req.text();
            let event;

            try {
                if (webhookSecret) {
                    event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
                } else {
                    console.warn("[Webhook] SECRET MISSING - Skipping verification (UNSAFE FOR PRODUCTION)");
                    event = JSON.parse(body); // Fallback for dev without secret
                }
            } catch (err) {
                console.error(`[Webhook] Verification failed: ${err.message}`);
                return new Response(`Webhook Error: ${err.message}`, { status: 400 });
            }

            console.log(`[Webhook] Processing event: ${event.type}`);

            switch (event.type) {
                case 'checkout.session.completed': {
                    const session = event.data.object;
                    const userId = session.metadata?.user_id;

                    if (userId) {
                        console.log(`[Webhook] Linking user ${userId} to Customer ${session.customer}`);
                        await supabase.from('subscriptions').upsert({
                            user_id: userId,
                            stripe_customer_id: session.customer,
                            stripe_subscription_id: session.subscription,
                            plan: 'ESSENTIAL', // Default derived from product logic or metadata
                            status: 'ACTIVE',
                            frequency: 'MONTHLY',
                            current_box_status: 'PREPARING',
                            auto_renew: true,
                            updated_at: new Date().toISOString()
                        }, { onConflict: 'user_id' });
                    }
                    break;
                }

                case 'customer.subscription.updated': {
                    const sub = event.data.object;
                    // Map Status
                    let status = 'ACTIVE';
                    if (['past_due', 'unpaid', 'paused'].includes(sub.status)) status = 'PAUSED';
                    if (['canceled'].includes(sub.status)) status = 'CANCELLED';

                    console.log(`[Webhook] Syncing subscription ${sub.id} -> Status: ${status}`);

                    await supabase.from('subscriptions').update({
                        status: status,
                        stripe_current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
                        auto_renew: !sub.cancel_at_period_end,
                        updated_at: new Date().toISOString()
                    }).eq('stripe_subscription_id', sub.id);
                    break;
                }

                case 'customer.subscription.deleted': {
                    const sub = event.data.object;
                    console.log(`[Webhook] Subscription ${sub.id} cancelled/deleted.`);
                    await supabase.from('subscriptions').update({
                        status: 'CANCELLED',
                        auto_renew: false,
                        updated_at: new Date().toISOString()
                    }).eq('stripe_subscription_id', sub.id);
                    break;
                }

                case 'invoice.payment_failed': {
                    const invoice = event.data.object;
                    if (invoice.subscription) {
                        console.log(`[Webhook] Payment failed for ${invoice.subscription}. Pausing access.`);
                        await supabase.from('subscriptions').update({
                            status: 'PAUSED', // Block Access
                            current_box_status: 'PAYMENT_PENDING' // Custom status for UI
                        }).eq('stripe_subscription_id', invoice.subscription);
                    }
                    break;
                }

                case 'invoice.payment_succeeded': {
                    const invoice = event.data.object;
                    if (invoice.subscription) {
                        // Only reset box status if it was stuck
                        console.log(`[Webhook] Payment succeeded for ${invoice.subscription}.`);
                        const { error } = await supabase.from('subscriptions').update({
                            status: 'ACTIVE',
                            // Optionally advance box cycle here if logic dictates
                        }).eq('stripe_subscription_id', invoice.subscription);
                    }
                    break;
                }
            }

            return new Response(JSON.stringify({ received: true }), { headers: { 'Content-Type': 'application/json' } });

        } else {
            // ==========================================
            //  CLIENT API HANDLING (Client-Server)
            // ==========================================

            // Auth Check
            const authHeader = req.headers.get('Authorization')
            if (!authHeader) {
                return new Response(JSON.stringify({ error: 'Missing Authorization' }), { status: 401, headers: corsHeaders })
            }
            const token = authHeader.replace('Bearer ', '')
            const { data: { user }, error: userError } = await supabase.auth.getUser(token)
            if (userError || !user) {
                console.error("[Auth Check Failed]", userError);
                return new Response(JSON.stringify({
                    error: `Unauthorized: ${userError?.message || 'User session not found'}`,
                    hint: "Check if user is logged in and email is confirmed."
                }), { status: 401, headers: corsHeaders })
            }

            const { action, priceId, returnUrl, session_id } = await req.json();

            // 1. Create Checkout Session
            if (action === 'create_checkout_session') {
                const session = await stripe.checkout.sessions.create({
                    customer_email: user.email,
                    line_items: [{ price: priceId, quantity: 1 }],
                    mode: 'subscription',
                    success_url: `${returnUrl}?session_id={CHECKOUT_SESSION_ID}`,
                    cancel_url: `${returnUrl}`,
                    metadata: { user_id: user.id }
                });
                return new Response(JSON.stringify({ url: session.url }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
            }

            // 2. Create Portal Session
            if (action === 'create_portal_session') {
                const { data: sub } = await supabase.from('subscriptions').select('stripe_customer_id').eq('user_id', user.id).single();
                if (!sub?.stripe_customer_id) throw new Error("No Customer ID found");

                const session = await stripe.billingPortal.sessions.create({
                    customer: sub.stripe_customer_id,
                    return_url: returnUrl,
                });
                return new Response(JSON.stringify({ url: session.url }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
            }

            // 3. Finalize/Sync (Manual Fallback for Client)
            if (action === 'finalize_checkout' || action === 'sync_subscription') {
                let subData;
                if (session_id) {
                    const session = await stripe.checkout.sessions.retrieve(session_id, { expand: ['subscription'] });
                    subData = session.subscription;

                    // Upsert Logic - USING CORRECT PORTUGUESE ENUMS
                    const { error: upsertError } = await supabase.from('subscriptions').upsert({
                        user_id: user.id,
                        stripe_customer_id: session.customer,
                        stripe_subscription_id: subData.id,
                        plan: 'ESSENTIAL',
                        status: 'ACTIVE',
                        frequency: 'Mensal', // Constraint: 'Mensal' or 'Trimestral'
                        current_box_status: 'Preparando sua Box', // Constraint: 'Preparando sua Box', etc.
                        updated_at: new Date().toISOString()
                    }, { onConflict: 'user_id' });

                    if (upsertError) {
                        console.error("Upsert Failed:", upsertError);
                        // Return error so client knows
                        return new Response(JSON.stringify({ error: `Database Error: ${upsertError.message}` }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
                    }

                } else {
                    // Sync by user ID query
                    const { data: localSub } = await supabase.from('subscriptions').select('stripe_subscription_id, stripe_customer_id').eq('user_id', user.id).maybeSingle();

                    if (localSub?.stripe_subscription_id) {
                        try {
                            if (localSub.stripe_subscription_id.includes('MANUAL_REPAIR')) {
                                return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
                            }

                            // 1. Fetch Subscription
                            subData = await stripe.subscriptions.retrieve(localSub.stripe_subscription_id);

                            let status = (subData.status === 'active' || subData.status === 'trialing') ? 'ACTIVE' : 'PAUSED';
                            if (subData.status === 'canceled') status = 'CANCELLED';

                            // Format Dates
                            const nextDate = new Date(subData.current_period_end * 1000).toLocaleDateString('pt-BR');
                            const memberSince = new Date(subData.created * 1000).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

                            // 2. Fetch Payment Method (Card info)
                            let billingInfo = { brand: '', lastFour: '', expiry: '' };
                            // Use default_payment_method from subscription or customer
                            const pmId = subData.default_payment_method || (await stripe.customers.retrieve(localSub.stripe_customer_id)).default_source; // simplistic fallback

                            // Better: List payment methods
                            const methods = await stripe.paymentMethods.list({ customer: localSub.stripe_customer_id, type: 'card' });
                            if (methods.data.length > 0) {
                                const card = methods.data[0].card;
                                billingInfo = {
                                    brand: card.brand,
                                    lastFour: card.last4,
                                    expiry: `${card.exp_month}/${card.exp_year}`
                                };
                            }

                            // 3. Update Tables
                            await Promise.all([
                                supabase.from('subscriptions').update({
                                    status,
                                    next_box_date: nextDate,
                                    member_since: memberSince,
                                    stripe_current_period_end: new Date(subData.current_period_end * 1000).toISOString(),
                                    updated_at: new Date().toISOString()
                                }).eq('user_id', user.id),

                                supabase.from('profiles').update({
                                    billing: billingInfo
                                }).eq('id', user.id)
                            ]);

                        } catch (stripeErr) {
                            console.error(`[Sync] Failed:`, stripeErr.message);
                            return new Response(JSON.stringify({ success: false, error: stripeErr.message }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
                        }
                    }
                }

                return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
            }

            // 4. Get Invoices
            if (action === 'get_invoices') {
                const { data: sub } = await supabase.from('subscriptions').select('stripe_customer_id').eq('user_id', user.id).single();
                if (!sub?.stripe_customer_id) return new Response(JSON.stringify({ invoices: [] }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

                try {
                    const invoices = await stripe.invoices.list({
                        customer: sub.stripe_customer_id,
                        limit: 5,
                        status: 'paid'
                    });

                    const formattedInvoices = invoices.data.map(inv => ({
                        id: inv.id,
                        number: inv.number,
                        amount: (inv.amount_paid / 100).toFixed(2),
                        date: new Date(inv.created * 1000).toLocaleDateString('pt-BR'),
                        pdf: inv.invoice_pdf,
                        status: inv.status
                    }));

                    return new Response(JSON.stringify({ invoices: formattedInvoices }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
                } catch (err) {
                    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
                }
            }

            return new Response(JSON.stringify({ error: 'Action not found' }), { status: 400, headers: corsHeaders });
        }

    } catch (error) {
    }
})
