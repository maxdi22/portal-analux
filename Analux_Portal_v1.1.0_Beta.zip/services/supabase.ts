
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://hidqwmjxekpzvmypbjzg.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpZHF3bWp4ZWtwenZteXBianpnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkzNTgyODcsImV4cCI6MjA4NDkzNDI4N30.xi_gKsQ1ogxkvTgV6txmwjgFPIs0kpkugeAb-l7fbi4';

export const supabase = createClient(supabaseUrl, supabaseKey);
