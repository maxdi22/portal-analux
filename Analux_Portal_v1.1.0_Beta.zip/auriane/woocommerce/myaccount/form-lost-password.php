<?php
/**
 * Lost password form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-lost-password.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_lost_password_form' );
?>

<form method="post" class="woocommerce-ResetPassword lost_reset_password">
    <h3><?php echo esc_html__('Lost password','auriane'); ?></h3>
    <p class="lost-notes"><?php echo apply_filters( 'woocommerce_lost_password_message', esc_html__( 'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'auriane' ) ); ?></p><?php // @codingStandardsIgnoreLine ?>
	<div class="form-lost">
        <p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
		  <input class="woocommerce-Input woocommerce-Input--text input-text" type="text" placeholder="<?php echo esc_attr_x( 'User name or email address *', 'placeholder', 'auriane' ); ?>" name="user_login" id="user_login" autocomplete="username" />
    	</p>
    	<div class="clear"></div>
    	<?php do_action( 'woocommerce_lostpassword_form' ); ?>
    	<p class="woocommerce-form-row form-row">
    		<input type="hidden" name="wc_reset_password" value="true" />
    		<button type="submit" class="woocommerce-Button button" value="<?php esc_attr_e( 'Reset password', 'auriane' ); ?>"><?php esc_html_e( 'Reset password', 'auriane' ); ?></button>
    	</p>
    </div>

	<?php wp_nonce_field( 'lost_password', 'woocommerce-lost-password-nonce' ); ?>

</form>
<?php
do_action( 'woocommerce_after_lost_password_form' );