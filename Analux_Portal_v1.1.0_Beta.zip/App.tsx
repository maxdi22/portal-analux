import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';

import DashboardHome from './components/DashboardHome';
import StyleDNA from './components/StyleDNA';
import Community from './components/Community';
import StyleAI from './components/StyleAI';
import SubscriptionManagement from './components/SubscriptionManagement';
import UserProfile from './components/UserProfile';
import ConnectedStore from './components/ConnectedStore';
import Editorial from './components/Editorial';
import LandingPage from './components/LandingPage';
import DigitalVault from './components/DigitalVault';
import AdminLayout from './components/admin/AdminLayout';
import AdminDashboard from './components/admin/AdminDashboard';
import AdminSubscribers from './components/admin/AdminSubscribers';
import AdminReferrals from './components/admin/AdminReferrals';
import BoxesDashboard from './components/admin/boxes/BoxesDashboard';
import CreateBox from './components/admin/boxes/CreateBox';
import MarketingCampaigns from './components/admin/MarketingCampaigns';
import { UserProvider, useUser } from './context/UserContext';
import { ToastProvider } from './context/ToastContext';
import { User } from './types';

import LayoutWrapper from './components/LayoutWrapper';

const ProtectedLayout: React.FC = () => {
  const { isMember } = useUser();

  if (!isMember) {
    return <Navigate to="/" replace />;
  }

  return <LayoutWrapper />;
};

const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isMember } = useUser();
  if (isMember) {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
};

const AppContent: React.FC = () => {
  const { user, updateUser, isMember, setIsMember, loading } = useUser();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-analux-contrast">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-analux-secondary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-analux-primary font-serif animate-pulse">Carregando seu brilho...</p>
        </div>
      </div>
    );
  }

  // Temporary wrapper to adapt existing components to context if they still expect props
  // In Phase 3, we will refactor these components to use context directly.
  // For now, we pass the context values as props to maintain compatibility.

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/convite/:code" element={<LandingPage />} />

      <Route element={<ProtectedLayout />}>
        <Route path="/dashboard" element={<DashboardHome user={user} onNavigate={() => { }} />} />
        <Route path="/style-dna" element={<StyleDNA />} />
        {/* <Route path="/editorial" element={<Editorial />} /> */}
        <Route path="/community" element={<Community />} />
        <Route path="/vault" element={<DigitalVault user={user} />} />
        {/* <Route path="/style" element={<StyleAI />} /> */}
        <Route path="/shop" element={<ConnectedStore />} />
        <Route path="/box" element={<SubscriptionManagement user={user} onUpdateUser={updateUser} />} />
        <Route path="/settings" element={<UserProfile user={user} onUpdate={updateUser} />} />

        {/* Fallback route */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>

      {/* Admin Portal Routes */}
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<Navigate to="/admin/dashboard" replace />} />
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="subscribers" element={<AdminSubscribers />} />
        <Route path="referrals" element={<AdminReferrals />} />

        {/* Boxes Module */}
        <Route path="boxes" element={<BoxesDashboard />} />
        <Route path="boxes/new" element={<CreateBox />} />

        {/* Marketing Module */}
        <Route path="marketing" element={<MarketingCampaigns />} />

        {/* Placeholder for other admin routes */}
        <Route path="*" element={<div className="p-10 text-slate-500">Módulo em construção...</div>} />
      </Route>
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <UserProvider>
      <ToastProvider>
        <BrowserRouter>
          <AppContent />
        </BrowserRouter>
      </ToastProvider>
    </UserProvider>
  );
};

export default App;
