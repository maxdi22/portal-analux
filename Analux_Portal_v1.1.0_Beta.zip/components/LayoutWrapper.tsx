
import React from 'react';
import { Outlet } from 'react-router-dom';
import { useIsMobile } from '../hooks/useIsMobile';
import Sidebar from './Sidebar';
import MobileLayout from './mobile/MobileLayout';
import { Toaster } from 'react-hot-toast';

const LayoutWrapper: React.FC = () => {
    const isMobile = useIsMobile();

    if (isMobile) {
        return (
            <>
                <MobileLayout />
                <Toaster position="top-center" />
            </>
        );
    }

    // Desktop Layout (Preserving original structure)
    return (
        <div className="flex min-h-screen bg-neutral-50 font-sans">
            <Sidebar />
            <main className="flex-1 ml-64 p-8 overflow-y-auto">
                <div className="max-w-7xl mx-auto space-y-8 pb-12">
                    <Outlet />
                </div>
            </main>
            <Toaster position="top-right" />
        </div>
    );
};

export default LayoutWrapper;
